package midexam.service;

import java.util.List;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import midexam.dao.UserDAO;
import midexam.entities.User;

@Repository("UserService")
@Transactional
public class UserServiceIpml implements UserService {

	@Autowired
	private UserDAO userDAO;

	@Override
	public List<User> showAll() {

		return userDAO.showAll();
	}

	@Override
	public void Add(User user) {
		userDAO.Add(user);
	}

	@Override
	public User findUser(Integer id) {

		return userDAO.findUser(id);
	}

	@Override
	public void Delete(User user) {
		userDAO.Delete(user);

	}

	@Override
	public void Edit(User user) {
		userDAO.Edit(user);

	}

	@Override
	public User findUserByUsername(String username) {
		
		return userDAO.findUserByUsername(username);
	}

}
