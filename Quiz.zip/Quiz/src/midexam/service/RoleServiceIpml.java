package midexam.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import midexam.dao.RoleDAO;
import midexam.entities.UserRole;

@Repository("RoleService")
@Transactional
public class RoleServiceIpml implements RoleService{

	@Autowired
	private RoleDAO roleDAO; 
	
	@Override
	public List<UserRole> showRole() {
		
		return roleDAO.showRole();
	}

}
