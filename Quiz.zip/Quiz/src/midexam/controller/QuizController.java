package midexam.controller;


import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import midexam.entities.Answer;
import midexam.entities.Category;
import midexam.entities.Exam;
import midexam.entities.ExamItem;
import midexam.entities.Quiz;
import midexam.service.AnswerService;
import midexam.service.CategoryService;
import midexam.service.ExamService;
import midexam.service.QuizService;
import midexam.validator.*;

@Controller
@RequestMapping(value = "/quiz**")
public class QuizController {

	@Autowired
	private QuizService quizService;

	@Autowired
	private AnswerService answerService;

	@Autowired
	private CategoryService categoryService;

	@Autowired
	private ExamService examService;

	@RequestMapping(method = RequestMethod.GET)
	public String welcome(ModelMap modelMap) {
		modelMap.addAttribute("message", "This is protected page - DB Page!");
		return "database";
	}

	/* QUESTION */
	/* Show List Questions */
	@RequestMapping(value = "/listquiz", method = RequestMethod.GET)
	public String showQuiz(ModelMap modelMap) {
		modelMap.put("quizs", quizService.showAll());
		return "listQuiz";
	}

	/* Add Question -GET */
	@RequestMapping(value = "/add", method = RequestMethod.GET)
	public String add(ModelMap modelMap) {

		modelMap.put("quiz", new Quiz());
		modelMap.put("categorys", categoryService.showAll());
		return "addQuiz";
	}

	/* Add Question -POST */
	@RequestMapping(value = "/add", method = RequestMethod.POST)
	public String add(@ModelAttribute(value = "quiz") @Valid Quiz quiz, BindingResult bindingResult) {
		QuizValidator quizValidator = new QuizValidator();
		quizValidator.validate(quiz, bindingResult);
		if (bindingResult.hasErrors()) {
			return "addQuiz";
		} else
			quizService.Add(quiz);
		return "redirect:/quiz/listquiz.html";
	}

	/* Delete Question */
	@RequestMapping(value = "/delete/{id}", method = RequestMethod.GET)
	public String delete(@PathVariable(value = "id") Integer id) {
		quizService.Delete(quizService.findQuiz(id));
		return "redirect:/quiz/listquiz.html";
	}

	/* Edit Question -GET */
	@RequestMapping(value = "/edit/{id}", method = RequestMethod.GET)
	public String edit(@PathVariable(value = "id") Integer id, ModelMap modelMap) {
		modelMap.put("quiz", quizService.findQuiz(id));
		modelMap.put("categorys", categoryService.showAll());
		return "editQuiz";
	}

	/* Edit Question -POST */
	@RequestMapping(value = "/edit", method = RequestMethod.POST)
	public String edit(@ModelAttribute(value = "quiz") @Valid Quiz quiz, BindingResult bindingResult,
			ModelMap modelMap) {
		QuizValidator quizValidator = new QuizValidator();
		quizValidator.validate(quiz, bindingResult);
		if (bindingResult.hasErrors()) {
			modelMap.put("categorys", categoryService.showAll());

			return "editQuiz";
		} else
			quiz.getCategory();
		quizService.Edit(quiz);
		return "redirect:/quiz/listquiz.html";
	}

	/* ANSWER */
	/* Show Answers of Question */
	@RequestMapping(value = "/modify/{id}", method = RequestMethod.GET)
	public String modify(@PathVariable(value = "id") Integer id, ModelMap modelMap) {
		modelMap.put("Qid", id);
		modelMap.put("answers", answerService.findAnswerByQuizID(id));
		return "listAnswer";
	}

	/* Add Answer -GET */
	@RequestMapping(value = "/modify/add/{id}", method = RequestMethod.GET)
	public String modifyAdd(@PathVariable(value = "id") Integer id, ModelMap modelMap) {
		modelMap.put("Qid", id);
		modelMap.put("answer", new Answer());
		// modelMap.put("quiz", quizService.findQuiz(id));
		// modelMap.put("quizs", quizService.showAll());
		return "addAnswer";
	}

	/* Add Answer -POST */
	@RequestMapping(value = "/modify/add", method = RequestMethod.POST)
	public String modifyAdd(@RequestParam(value = "Qid") Integer Qid,
			@ModelAttribute(value = "answer") @Valid Answer answer, BindingResult bindingResult, ModelMap modelMap) {
		AnswerValidator answerValidator = new AnswerValidator();
		answerValidator.validate(answer, bindingResult);
		if (bindingResult.hasErrors()) {
			// modelMap.put("quizs", quizService.showAll());
			return "addAnswer";
		} else
			answer.setQuiz(quizService.findQuiz(Qid));
		answerService.Add(answer);
		return "redirect:/quiz/modify/" + Qid + ".html";
	}

	/* Delete Answer */
	@RequestMapping(value = "/modify/delete/{id}", method = RequestMethod.GET)
	public String modifyDelete(@PathVariable(value = "id") Integer id) {
		answerService.Delete(answerService.findAnswer(id));
		return "redirect:/quiz/listquiz.html";
	}

	/* Edit Answer -GET */
	@RequestMapping(value = "/modify/edit/{id}", method = RequestMethod.GET)
	public String modifyEdit(@PathVariable(value = "id") Integer id, ModelMap modelMap) {
		modelMap.put("answer", answerService.findAnswer(id));
		return "editAnswer";
	}

	/* Edit Answer -POST */
	@RequestMapping(value = "/modify/edit", method = RequestMethod.POST)
	public String modify(@ModelAttribute(value = "answer") @Valid Answer answer, BindingResult bindingResult) {
		AnswerValidator answerValidator = new AnswerValidator();
		answerValidator.validate(answer, bindingResult);
		if (bindingResult.hasErrors()) {

			return "editAnswer";
		} else
			answerService.Edit(answer);
		return "redirect:/quiz/listquiz.html";
	}

	/* COURSE */
	/* Show Category of Courses */
	@RequestMapping(value = "/category", method = RequestMethod.GET)
	public String showCourse(ModelMap modelMap) {
		modelMap.put("category", categoryService.showAll());
		return "category";
	}

	/* Add Course -GET */
	@RequestMapping(value = "/category/add", method = RequestMethod.GET)
	public String courseAdd(ModelMap modelMap) {
		modelMap.put("category", new Category());
		return "addCourse";
	}

	/* Add Course -POST */
	@RequestMapping(value = "/category/add", method = RequestMethod.POST)
	public String courseAdd(@ModelAttribute(value = "category") @Valid Category category, BindingResult bindingResult,
			ModelMap modelMap) {
		CategoryValidator categoryValidator = new CategoryValidator();
		categoryValidator.validate(category, bindingResult);
		if (bindingResult.hasErrors()) {

			return "addCourse";
		} else
			categoryService.Add(category);
		return "redirect:/quiz/category.html";
	}

	/* Delete Course */
	@RequestMapping(value = "/category/delete/{id}", method = RequestMethod.GET)
	public String couserDelete(@PathVariable(value = "id") Integer id) {
		categoryService.Delete(categoryService.findCourse(id));
		return "redirect:/quiz/category.html";
	}

	/* Edit Course -GET */
	@RequestMapping(value = "/category/edit/{id}", method = RequestMethod.GET)
	public String courseEdit(@PathVariable(value = "id") Integer id, ModelMap modelMap) {
		modelMap.put("category", categoryService.findCourse(id));
		return "editCourse";
	}

	/* Edit Course -POST */
	@RequestMapping(value = "/category/edit", method = RequestMethod.POST)
	public String courseEdit(@ModelAttribute(value = "category") @Valid Category category,
			BindingResult bindingResult) {
		CategoryValidator categoryValidator = new CategoryValidator();
		categoryValidator.validate(category, bindingResult);
		if (bindingResult.hasErrors()) {

			return "editCourse";
		} else
			categoryService.Edit(category);
		return "redirect:/quiz/category.html";
	}

	/* EXAM */
	/* Show Exams */
	@RequestMapping(value = "/listexam", method = RequestMethod.GET)
	public String showExam(ModelMap modelMap) {
		modelMap.put("exams", examService.showAll());

		return "listExam";
	}

	/* View Detail Exam */
	@RequestMapping(value = "/listexam/view/{id}", method = RequestMethod.GET)
	public String viewExam(@PathVariable(value = "id") Integer id, ModelMap modelMap) {
		modelMap.put("exam", examService.findExamByID(id));
		modelMap.put("quizs", quizService.findQuizByExamId(id));

		// modelMap.put("number", quizService.findQuizByExamId(id).size());
		return "viewExam";
	}

	@RequestMapping(value = "/listexam/remove/{Eid}/{Qid}", method = RequestMethod.GET)
	public String examRemove(@PathVariable(value = "Eid") Integer Eid, @PathVariable(value = "Qid") Integer Qid) {
		examService.Remove(examService.findExamItemByID(Eid, Qid));
		return "redirect:/quiz/listexam/view/" + Eid + ".html";
	}

	/* Add Exam -GET */
	@RequestMapping(value = "/listexam/add", method = RequestMethod.GET)
	public String examAdd(ModelMap modelMap) {
		modelMap.put("exam", new Exam());
		modelMap.put("categorys", categoryService.showAll());

		return "addExam";
	}

	/* Add Exam -POST */
	@RequestMapping(value = "/listexam/add", method = RequestMethod.POST)
	public String examAdd(@ModelAttribute(value = "exam") @Valid Exam exam, BindingResult bindingResult,
			ModelMap modelMap) {
		ExamValidator examValidator = new ExamValidator();
		examValidator.validate(exam, bindingResult);
		if (bindingResult.hasErrors()) {
			modelMap.put("categorys", categoryService.showAll());

			return "addExam";
		} else
			examService.Add(exam);
		return "redirect:/quiz/listexam.html";
	}

	/* Delete Exam */
	@RequestMapping(value = "/listexam/delete/{id}", method = RequestMethod.GET)
	public String examDelete(@PathVariable(value = "id") Integer id) {
		examService.Delete(examService.findExamByID(id));
		return "redirect:/quiz/listexam.html";
	}

	/* Edit Exam -GET */
	@RequestMapping(value = "/listexam/edit/{id}", method = RequestMethod.GET)
	public String examEdit(@PathVariable(value = "id") Integer id, ModelMap modelMap) {
		modelMap.put("exam", examService.findExamByID(id));
		modelMap.put("categorys", categoryService.showAll());

		return "editExam";
	}

	/* Edit Exam -POST */
	@RequestMapping(value = "/listexam/edit", method = RequestMethod.POST)
	public String examEdit(@ModelAttribute(value = "exam") @Valid Exam exam, BindingResult bindingResult,
			ModelMap modelMap) {
		ExamValidator examValidator = new ExamValidator();
		examValidator.validate(exam, bindingResult);
		if (bindingResult.hasErrors()) {
			modelMap.put("categorys", categoryService.showAll());
			return "editCourse";
		} else
			examService.Edit(exam);
		return "redirect:/quiz/listexam.html";
	}

	/* Exam Item */
	/* Insert Question into Exam -GET */
	/*
	 * @RequestMapping(value = "/listexam/insert/{id}", method =
	 * RequestMethod.GET) public String insertQtoE(@PathVariable(value = "id")
	 * Integer id, ModelMap modelMap) { modelMap.put("examID", id);
	 * modelMap.put("exam", examService.findExamByID(id));
	 * modelMap.put("number",
	 * quizService.findQuizByExamId(examService.findExamByID(id).getCategory().
	 * getId()).size());
	 * 
	 * // Search Questions have Course ID modelMap.put("quizs",
	 * quizService.findQuizByCourseId(examService.findExamByID(id).getCategory()
	 * .getId())); //
	 * System.out.println(examService.findExamByID(id).getCategory().getId());
	 * 
	 * return "insertQuiz"; }
	 */

	@RequestMapping(value = "/listexam/insert/{id}", method = RequestMethod.GET)
	public String insertQtoE(@PathVariable(value = "id") Integer id, ModelMap modelMap) {
		modelMap.put("examID", id);

		Exam exam = examService.findExamByID(id);

		List<Quiz> lqcid = quizService.findQuizByCourseId(exam.getCategory().getId());
		List<Quiz> lqeid = quizService.findQuizByExamId(id);
		System.out.println(lqeid.size());

		List<Integer> lqcidInteger = new ArrayList<>();
		for (Quiz question : lqcid)
			lqcidInteger.add(question.getId());

		List<Integer> lqeidInteger = new ArrayList<>();
		for (Quiz question : lqeid) {
			lqeidInteger.add(question.getId());
		}

		// System.out.println("=========================");
		// System.out.println(" List Question by course ID (Question Bank) = " +
		// lqcid.size());
		// System.out.print(" List Question by course ID - Item = ");
		// for (Quiz question : lqcid)
		// System.out.print(question.getId() + " ");
		//
		// System.out.println("");
		// System.out.println(" List Question by exam ID (Examitem) = " +
		// lqeid.size());
		// System.out.print(" List Question by exam ID - Item = ");
		// for (Quiz question : lqeid)
		// System.out.print(question.getId() + " ");
		// System.out.println("");
		// System.out.println("=========================");

		List<Quiz> addQuestion = new ArrayList<>();
		List<Integer> addQuestionInteger = new ArrayList<>();
		for (int i = 0; i < lqcid.size(); i++) { // chay list lon
			if (lqeidInteger.contains(lqcidInteger.get(i))) { // neu list ei da
																// chua thi ko
																// lam gi ca

			} else { // neu ko chua thi add vao
				addQuestionInteger.add(lqcidInteger.get(i));
			}
		}

		for (Integer integer : addQuestionInteger) {
			System.out.println(integer);
		}
		for (int i = 0; i < addQuestionInteger.size(); i++) {
			addQuestion.add(quizService.findQuiz(addQuestionInteger.get(i)));
		}
		modelMap.put("number", addQuestion.size());
		modelMap.put("exam", exam);
		modelMap.put("quizs", addQuestion);

		return "insertQuiz";
	}

	/* Insert Question into Exam -POST */
	@RequestMapping(value = "/listexam/insert", method = RequestMethod.POST)
	public String insertQtoE(@RequestParam(value = "examID") Integer examID,
			@RequestParam(value = "number") Integer number, HttpServletRequest request,
			ModelMap modelMap) {
		Integer questionid;

		// ExamItem examItem = new ExamItem();
		// examItem.setExam(examService.findExamByID(examID));
		Integer checked = 0;

		for (int i = 0; i < number; i++) {

			if (request.getParameter("quizid_" + i) != null) {

				checked++;
			}
		}

		if (examService.findExamByID(examID).getExamItems().size() + checked > examService.findExamByID(examID)
				.getNumOfQuestion() + 10) {
			

			modelMap.put("msg", "Khong the add them cau hoi");
			
			
				return "redirect:/quiz/listexam/insert/"+ examID+".html";
		} else {
			// Add Question To Exam
			for (int i = 0; i < number; i++) {

				if (request.getParameter("quizid_" + i) != null) {

					questionid = Integer.parseInt(request.getParameter("quizid_" + i));

					ExamItem examItem = new ExamItem();
					examItem.setExam(examService.findExamByID(examID));

					examItem.setQuiz(quizService.findQuiz(questionid));

					examService.Insert(examItem);

					// if(examService.findExamByID(examID).get)
				}
			}
		}
		return "redirect:/quiz/listexam.html";

	}
}