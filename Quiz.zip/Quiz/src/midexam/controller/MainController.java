package midexam.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AnonymousAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.web.authentication.logout.SecurityContextLogoutHandler;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.*;

import midexam.service.UserService;

@Controller
@RequestMapping(value = "/main")
public class MainController {

	@Autowired
	private UserService userService;

	@RequestMapping(method = RequestMethod.GET)
	public String index(ModelMap modelMap) {
		return "login";
	}

	/* Login */
	@RequestMapping(value = "/login", method = RequestMethod.GET)
	public String login(@RequestParam(value = "error", required = false) String error,
			@RequestParam(value = "logout", required = false) String logout, ModelMap mm) {
		if (error != null) {
			mm.addAttribute("msg", "Invalid username and password! Do you have account?");
		}
		if (logout != null) {
			mm.addAttribute("msg", "You've been logged out successfully.");
		}
		return "login";
	}

	/* Logout */
	@RequestMapping(value = "/logout", method = RequestMethod.GET)
	public String logout(HttpServletRequest request, HttpServletResponse response) {
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		if (auth != null) {
			new SecurityContextLogoutHandler().logout(request, response, auth);
			System.out.println("Da logout");
			System.out.println(request);
			System.out.println(response);
			System.out.println(auth);
		}
		return "redirect:/main.html";
	}

	/* 403 Page */
	@RequestMapping(value = "/403", method = RequestMethod.GET)
	public String accesssDenied(ModelMap mm) {
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		if (!(auth instanceof AnonymousAuthenticationToken)) {
			UserDetails userDetail = (UserDetails) auth.getPrincipal();
			mm.addAttribute("username", userDetail.getUsername());
		}
		return "403";
	}

	/* Welcome Page */
	@RequestMapping(value = "/welcome", method = RequestMethod.GET)
	public String welcome(ModelMap modelMap) {
		String rolename = "";
		Integer roleID=0;
		String admin_role = "ROLE_ADMIN";
		String dba_role = "ROLE_DB";
		String user_role = "ROLE_USER";

		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		if (!(auth instanceof AnonymousAuthenticationToken)) {
			UserDetails userDetail = (UserDetails) auth.getPrincipal();
			rolename = userService.findUserByUsername(userDetail.getUsername()).getUserRole().getRoleName();
			roleID = userService.findUserByUsername(userDetail.getUsername()).getUserRole().getId();
		}

		modelMap.put("roleID", roleID);
		String result = "";

		if (rolename.equals(admin_role)) {
			result = "homeAdmin";
		} else if (rolename.equals(dba_role)) {
			result = "homeDBA";
		} else if (rolename.equals(user_role)) {
			result = "homeUser";
		}
		return result;
	}

}