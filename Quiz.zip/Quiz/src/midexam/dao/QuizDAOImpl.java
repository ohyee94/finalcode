package midexam.dao;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.Vector;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import midexam.entities.Exam;
import midexam.entities.Quiz;

@Repository("QuizDAO")
@Transactional
public class QuizDAOImpl implements QuizDAO{

	@Autowired
	private SessionFactory sessionFactory;
	
	@SuppressWarnings("unchecked")
	@Override
	public List<Quiz> showAll() {
		
		return sessionFactory.getCurrentSession().createCriteria(Quiz.class).list();
	}

	@Override
	public void Add(Quiz quiz) {
		sessionFactory.getCurrentSession().persist(quiz);
		
	}

	@Override
	public Quiz findQuiz(Integer id) {
		return (Quiz) sessionFactory.getCurrentSession().get(Quiz.class, id);
	}

	@Override
	public void Delete(Quiz quiz) {
		
		sessionFactory.getCurrentSession().delete(quiz);
	}

	@Override
	public void Edit(Quiz quiz) {
		
		sessionFactory.getCurrentSession().saveOrUpdate(quiz);
	}

	

	
//	@SuppressWarnings("unchecked")
//	public List<Quiz> findQuizByExamId(Integer id){
//		return sessionFactory.getCurrentSession().createSQLQuery("select * from midexam.exam_item where exam_id = :id").addEntity(ExamItem.class).setParameter("id", id).list();
//		
//	}
	@SuppressWarnings("unchecked")
	public List<Quiz> findQuizByExamId(Integer id){
		List<Integer> ls = sessionFactory.getCurrentSession().createSQLQuery("select quiz_id from midexam.exam_item where exam_id = :id").setParameter("id", id).list();
		
		List<Quiz> lq = new ArrayList<>();
		for(Integer integer : ls){
			lq.add(findQuiz(integer)); System.out.println(integer);
			
			}
		return lq;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Quiz> findQuizByCourseId(Integer id) {
		
		return sessionFactory.getCurrentSession().createSQLQuery("select * from midexam.quiz where category_id = :id").addEntity(Quiz.class).setParameter("id", id).list();
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Quiz> RandomQuiz(Integer id) {
		List<Integer> aN = new ArrayList<>();
		List<Quiz> a = new ArrayList<>();
		List<Quiz> b = new ArrayList<>();
//		Integer numQ = sessionFactory.getCurrentSession().createSQLQuery("select num_of_question from midexam.exam where id = :id").setParameter("id", id).;
		Exam e = (Exam)sessionFactory.getCurrentSession().get(Exam.class, id);
		Integer numQ = e.getNumOfQuestion();
		System.out.println(numQ);
		
		@SuppressWarnings("rawtypes")
		Vector v = new Vector(); 
		Random rd = new Random(); 
		int iNew = 0;
		aN = sessionFactory.getCurrentSession()
				.createSQLQuery("select quiz_id from midexam.exam_item where exam_id = :id")
				.setParameter("id", id).list();

		for(Integer integer : aN){
			a.add(findQuiz(integer)); 
			
			}

		for (int i = 0; i < numQ;) {
		iNew = rd.nextInt(a.size());
		if (!v.contains(iNew)) {
		v.add(iNew);
		i++;
		}
		}
		for (int i = 0; i < numQ; i++ ){
		b.add(a.get((int) v.get(i)));
		}

		return b;

	}
	
}

	
