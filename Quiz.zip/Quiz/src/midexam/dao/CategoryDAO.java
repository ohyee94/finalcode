package midexam.dao;
import midexam.entities.*;
import java.util.*;
public interface CategoryDAO {
	public List<Category> showAll();
	public void Add(Category category);
	public Category findCourse(Integer id);
	public void Delete(Category category);
	public void Edit(Category category);
}
