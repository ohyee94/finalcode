package midexam.dao;

import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import midexam.entities.Category;

@Repository("CategoryDAO")
@Transactional
public class CategoryDAOIpml implements CategoryDAO{

	@Autowired
	private SessionFactory sessionFactory; 
	
	@SuppressWarnings("unchecked")
	@Override
	public List<Category> showAll() {
		
		return sessionFactory.getCurrentSession().createCriteria(Category.class).list();
	}

	@Override
	public void Add(Category category) {
		sessionFactory.getCurrentSession().persist(category);
		
	}

	@Override
	public Category findCourse(Integer id) {
		
		return (Category) sessionFactory.getCurrentSession().get(Category.class, id);
	}

	@Override
	public void Delete(Category category) {
		sessionFactory.getCurrentSession().delete(category);
		
	}

	@Override
	public void Edit(Category category) {
		sessionFactory.getCurrentSession().saveOrUpdate(category);
	}

}
