package midexam.dao;

import java.util.List;

import midexam.entities.User;

public interface UserDAO {
	public List<User> showAll();
	public void Add(User user);
	public User findUser(Integer id);
	public void Delete(User user);
	public void Edit(User user);
	public User findUserByUsername(String username);
}
