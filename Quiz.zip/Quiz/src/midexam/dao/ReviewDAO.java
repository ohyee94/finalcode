package midexam.dao;

import midexam.entities.*;
import java.util.*;

public interface ReviewDAO {

	public void Add(Review review);
	public List<Review> findReviewByResultID(Integer id);
}
