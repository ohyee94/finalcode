package midexam.dao;

import java.util.*;
import midexam.entities.*;

public interface ResultDAO {
	public List<Result> findResultByUserID(Integer id);

	public Review findReviewByResultID(Integer id);
	public List<Result> showAll();
	public void Add(Result result);
	public void Edit(Result result);
}
