package midexam.service;

import java.util.List;

import midexam.entities.Result;
import midexam.entities.Review;

public interface ResultService {
	public List<Result> findResultByUserID(Integer id);
	public Review findReviewByResultID(Integer id);
	public List<Result> showAll();
	public void Add(Result result);
	public void Edit(Result result);
}
