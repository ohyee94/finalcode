package midexam.service;

import java.util.*;
import midexam.entities.*;

public interface RoleService {
	public List<UserRole> showRole();
}
