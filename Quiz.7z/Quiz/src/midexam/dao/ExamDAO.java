package midexam.dao;
import java.util.*;
import midexam.entities.*;
public interface ExamDAO {
	public List<Exam> showAll();
	public Exam findExamByID(Integer id);
	public void Add(Exam exam);
	public void Edit(Exam exam);
	public void Delete(Exam exam);
	public void Insert(ExamItem examItem);
	public void Remove(ExamItem examItem);
	public ExamItem findExamItemByID(Integer Eid,Integer Qid);

}
