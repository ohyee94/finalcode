package midexam.dao;

import java.util.List;



import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import midexam.entities.User;

@Repository("UserDAO")
@Transactional
public class UserDAOIpml implements UserDAO{

	@Autowired
	private SessionFactory sessionFactory;
	
	@SuppressWarnings("unchecked")
	@Override
	public List<User> showAll() {
		
		return sessionFactory.getCurrentSession().createCriteria(User.class).list();
	}

	@Override
	public void Add(User user) {
		sessionFactory.getCurrentSession().persist(user);		
	}

	@Override
	public User findUser(Integer id) {
		
		return (User) sessionFactory.getCurrentSession().get(User.class, id);
	}

	@Override
	public void Delete(User user) {
		sessionFactory.getCurrentSession().delete(user);
		
	}

	@Override
	public void Edit(User user) {
		sessionFactory.getCurrentSession().saveOrUpdate(user);
		
	}

	@Override
	public User findUserByUsername(String username) {
		
		return (User) sessionFactory.getCurrentSession().
				createCriteria(User.class).
				add(Restrictions.eq("userName", username)).uniqueResult();
	}

	
}
