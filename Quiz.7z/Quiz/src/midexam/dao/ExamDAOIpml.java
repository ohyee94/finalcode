package midexam.dao;

import java.util.List;

import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import midexam.entities.Category;
import midexam.entities.Exam;
import midexam.entities.ExamItem;

@Repository("ExamDAO")
@Transactional
public class ExamDAOIpml implements ExamDAO{

	@Autowired
	private SessionFactory sessionFactory;
	
	@SuppressWarnings("unchecked")
	@Override
	public List<Exam> showAll() {
		
		return sessionFactory.getCurrentSession().createCriteria(Exam.class).list(); 
	}

	@Override
	public Exam findExamByID(Integer id) {
		
		return (Exam) sessionFactory.getCurrentSession().get(Exam.class, id);
	}

	@Override
	public void Add(Exam exam) {
		sessionFactory.getCurrentSession().persist(exam);
		
	}

	@Override
	public void Edit(Exam exam) {
		sessionFactory.getCurrentSession().saveOrUpdate(exam);
	}

	@Override
	public void Delete(Exam exam) {
		sessionFactory.getCurrentSession().delete(exam);
		
	}

	@Override
	public void Insert(ExamItem examItem) {
		sessionFactory.getCurrentSession().persist(examItem);
	}

	@Override
	public void Remove(ExamItem examItem) {
		sessionFactory.getCurrentSession().delete(examItem);
		
	}

	@Override
	public ExamItem findExamItemByID(Integer Eid,Integer Qid) {
		
		return (ExamItem) sessionFactory.getCurrentSession()
				.createCriteria(ExamItem.class)
				.add(Restrictions.eq("exam.id", Eid))
				.add(Restrictions.eq("quiz.id",Qid)).uniqueResult();
	}





	
	
}
